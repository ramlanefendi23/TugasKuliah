import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int nilai = input.nextInt() ;
    for (int i = 0; i < nilai ; i++) {
            System.out.print(i+" ");
        }

    }
}

