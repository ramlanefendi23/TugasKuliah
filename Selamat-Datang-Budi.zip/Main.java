class Main {
  public static void main(String[] args) {
    String nama = ("Muhammad Affandes");
    System.out.println("Hai " + "Muhammad Affandes");
    System.out.println("Selamat datang di MyApp.");
    System.out.println("========================");
    System.out.println("Terimakasih " + "Muhammad Affandes" + " sudah membeli aplikasi ini.");
    System.out.println("Support: support@myapp.co.id");
  }
}