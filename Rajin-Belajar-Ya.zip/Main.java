class Main {
  public static void main(String[] args) {
    String var="Saya berkata, \"Rajin belajar, ya!\"";
    System.out.print(var);
  }
}