class Main {
  public static void main(String[] args) {
   for (int nilai = 1; nilai < 21; nilai++) {
            System.out.println("Saya berjanji akan rajin belajar Java!");
        }
        
    }
}